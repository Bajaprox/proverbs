
use std::iter::Peekable;
use std::str::Chars;

#[derive(Debug, PartialEq, Clone)]
pub enum Token {
    // Keywords
    Let,
    If,
    Else,
    Function,
    Return,
    
    // Literals
    Identifier(String),
    String(String),
    Number(f64),
    
    // Operators
    Plus,
    Minus,
    Asterisk,
    Slash,
    Assign,
    Equal,
    NotEqual,
    LessThan,
    GreaterThan,
    
    // Delimiters
    LParen,
    RParen,
    LBrace,
    RBrace,
    Comma,
    Semicolon,
    
    EOF
}

pub struct Lexer<'a> {
    input: Peekable<Chars<'a>>,
    position: usize,
}

impl<'a> Lexer<'a> {
    pub fn new(input: &'a str) -> Self {
        Lexer {
            input: input.chars().peekable(),
            position: 0,
        }
    }

    fn read_char(&mut self) -> Option<char> {
        let ch = self.input.next();
        if ch.is_some() {
            self.position += 1;
        }
        ch
    }

    fn peek_char(&mut self) -> Option<&char> {
        self.input.peek()
    }

    fn skip_whitespace(&mut self) {
        while let Some(&ch) = self.peek_char() {
            if !ch.is_whitespace() {
                break;
            }
            self.read_char();
        }
    }

    fn read_identifier(&mut self, first_char: char) -> String {
        let mut identifier = String::from(first_char);
        
        while let Some(&ch) = self.peek_char() {
            if !ch.is_alphanumeric() && ch != '_' {
                break;
            }
            identifier.push(self.read_char().unwrap());
        }
        
        identifier
    }

    fn read_number(&mut self, first_char: char) -> f64 {
        let mut number = String::from(first_char);
        let mut has_decimal = false;
        
        while let Some(&ch) = self.peek_char() {
            if ch == '.' && !has_decimal {
                has_decimal = true;
                number.push(self.read_char().unwrap());
            } else if ch.is_digit(10) {
                number.push(self.read_char().unwrap());
            } else {
                break;
            }
        }
        
        number.parse().unwrap()
    }

    fn read_string(&mut self) -> String {
        let mut string = String::new();
        
        while let Some(ch) = self.read_char() {
            if ch == '"' {
                break;
            }
            string.push(ch);
        }
        
        string
    }

    pub fn next_token(&mut self) -> Token {
        self.skip_whitespace();
        
        match self.read_char() {
            Some(ch) => match ch {
                '=' => {
                    if let Some(&'=') = self.peek_char() {
                        self.read_char();
                        Token::Equal
                    } else {
                        Token::Assign
                    }
                },
                '+' => Token::Plus,
                '-' => Token::Minus,
                '*' => Token::Asterisk,
                '/' => Token::Slash,
                '(' => Token::LParen,
                ')' => Token::RParen,
                '{' => Token::LBrace,
                '}' => Token::RBrace,
                ',' => Token::Comma,
                ';' => Token::Semicolon,
                '<' => Token::LessThan,
                '>' => Token::GreaterThan,
                '"' => Token::String(self.read_string()),
                ch if ch.is_alphabetic() || ch == '_' => {
                    let identifier = self.read_identifier(ch);
                    match identifier.as_str() {
                        "let" => Token::Let,
                        "if" => Token::If,
                        "else" => Token::Else,
                        "fn" => Token::Function,
                        "return" => Token::Return,
                        _ => Token::Identifier(identifier),
                    }
                },
                ch if ch.is_digit(10) => Token::Number(self.read_number(ch)),
                _ => Token::EOF,
            },
            None => Token::EOF,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_next_token() {
        let input = r#"let x = 42;
            let y = "hello";
            if x < 10 {
                return y;
            }"#;
        
        let mut lexer = Lexer::new(input);
        let expected_tokens = vec![
            Token::Let,
            Token::Identifier("x".to_string()),
            Token::Assign,
            Token::Number(42.0),
            Token::Semicolon,
            Token::Let,
            Token::Identifier("y".to_string()),
            Token::Assign,
            Token::String("hello".to_string()),
            Token::Semicolon,
            Token::If,
            Token::Identifier("x".to_string()),
            Token::LessThan,
            Token::Number(10.0),
            Token::LBrace,
            Token::Return,
            Token::Identifier("y".to_string()),
            Token::Semicolon,
            Token::RBrace,
        ];

        for expected_token in expected_tokens {
            assert_eq!(lexer.next_token(), expected_token);
        }
    }
}
