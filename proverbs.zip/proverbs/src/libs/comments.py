
from typing import List, Optional

class Comment:
    def __init__(self, text: str, line: int, column: int):
        self.text = text.strip()
        self.line = line
        self.column = column

class CommentHandler:
    def __init__(self):
        self.single_line_comment = "//"
        self.multi_line_start = "/*"
        self.multi_line_end = "*/"
        self.comments: List[Comment] = []

    def parse_comments(self, source: str) -> List[Comment]:
        """Parse comments from source code and return list of Comment objects"""
        lines = source.split('\n')
        self.comments = []
        in_multi_line = False
        multi_line_start_pos = (0, 0)

        for line_num, line in enumerate(lines, 1):
            if not in_multi_line:
                # Check for single line comments
                if self.single_line_comment in line:
                    idx = line.index(self.single_line_comment)
                    comment_text = line[idx + len(self.single_line_comment):]
                    self.comments.append(Comment(comment_text, line_num, idx))
                    continue

                # Check for multi-line comment start
                if self.multi_line_start in line:
                    idx = line.index(self.multi_line_start)
                    in_multi_line = True
                    multi_line_start_pos = (line_num, idx)
                    continue

            else:
                # Check for multi-line comment end
                if self.multi_line_end in line:
                    idx = line.index(self.multi_line_end)
                    end_idx = idx + len(self.multi_line_end)
                    multi_line_text = '\n'.join(
                        lines[multi_line_start_pos[0] - 1:line_num]
                    )
                    self.comments.append(
                        Comment(
                            multi_line_text,
                            multi_line_start_pos[0],
                            multi_line_start_pos[1]
                        )
                    )
                    in_multi_line = False

        return self.comments

    def strip_comments(self, source: str) -> str:
        """Remove all comments from source code"""
        result = []
        lines = source.split('\n')
        in_multi_line = False

        for line in lines:
            if not in_multi_line:
                if self.single_line_comment in line:
                    idx = line.index(self.single_line_comment)
                    result.append(line[:idx].rstrip())
                    continue

                if self.multi_line_start in line:
                    idx = line.index(self.multi_line_start)
                    result.append(line[:idx].rstrip())
                    in_multi_line = True
                    continue

                result.append(line)
            else:
                if self.multi_line_end in line:
                    idx = line.index(self.multi_line_end)
                    end_idx = idx + len(self.multi_line_end)
                    result.append(line[end_idx:].lstrip())
                    in_multi_line = False

        return '\n'.join(result)

    def get_comment_at_position(self, line: int, column: int) -> Optional[Comment]:
        """Get comment at specific position if exists"""
        for comment in self.comments:
            if comment.line == line and comment.column == column:
                return comment
        return None
