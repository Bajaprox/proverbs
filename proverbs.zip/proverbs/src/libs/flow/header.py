class Header:
    def __init__(self):
        self.encoding = "utf-8"
        self.version = "1.0"
        self.language = "proverbs"
        self.interpreter = "proverbs-lang"

    def parse_header(self, header_line):
        """Parse a header line from a Proverbs source file"""
        if header_line.startswith("#!"):
            parts = header_line[2:].strip().split()
            for part in parts:
                if "encoding=" in part:
                    self.encoding = part.split("=")[1]
                elif "version=" in part:
                    self.version = part.split("=")[1]
                elif "interpreter=" in part:
                    self.interpreter = part.split("=")[1]

    def generate_header(self):
        """Generate a standard header for Proverbs source files"""
        return f"#! encoding={self.encoding} version={self.version} interpreter={self.interpreter}"

    def validate_header(self, header_line):
        """Validate if the header is correct for Proverbs language"""
        if not header_line.startswith("#!"):
            return False
        required_fields = ["encoding", "version", "interpreter"]
        for field in required_fields:
            if field not in header_line:
                return False
        return True
