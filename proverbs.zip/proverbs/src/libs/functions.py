def get_file_extension(filename):
    """Get the file extension from a filename."""
    return filename.split('.')[-1].lower() if '.' in filename else ''

def is_valid_file_type(filename, allowed_extensions):
    """Check if the file type is allowed."""
    return get_file_extension(filename) in allowed_extensions

def sanitize_filename(filename):
    """Remove invalid characters from filename."""
    import re
    # Remove invalid characters
    filename = re.sub(r'[<>:"/\\|?*]', '', filename)
    # Remove control characters
    filename = "".join(char for char in filename if ord(char) >= 32)
    return filename.strip()

def create_unique_filename(base_path, filename):
    """Create a unique filename by adding a number if file exists."""
    import os
    name, ext = os.path.splitext(filename)
    counter = 1
    new_filename = filename
    
    while os.path.exists(os.path.join(base_path, new_filename)):
        new_filename = f"{name}_{counter}{ext}"
        counter += 1
    
    return new_filename

def ensure_directory_exists(directory_path):
    """Create directory if it doesn't exist."""
    import os
    if not os.path.exists(directory_path):
        os.makedirs(directory_path)

def get_file_size(file_path):
    """Get file size in bytes."""
    import os
    return os.path.getsize(file_path)

def format_file_size(size_in_bytes):
    """Convert file size to human readable format."""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_in_bytes < 1024.0:
            return f"{size_in_bytes:.2f} {unit}"
        size_in_bytes /= 1024.0
    return f"{size_in_bytes:.2f} PB"

def get_mime_type(file_path):
    """Get MIME type of a file."""
    import mimetypes
    mime_type, _ = mimetypes.guess_type(file_path)
    return mime_type or 'application/octet-stream'

def is_image_file(filename):
    """Check if file is an image based on extension."""
    image_extensions = {'jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'}
    return get_file_extension(filename) in image_extensions

def calculate_file_hash(file_path, hash_algorithm='sha256'):
    """Calculate file hash using specified algorithm."""
    import hashlib
    hash_func = getattr(hashlib, hash_algorithm)()
    
    with open(file_path, 'rb') as f:
        for chunk in iter(lambda: f.read(4096), b''):
            hash_func.update(chunk)
    
    return hash_func.hexdigest()
