
import re
from typing import List, Tuple

def tokenize(source: str) -> List[Tuple[str, str]]:
    """
    Tokenize source code string into list of (token_type, value) tuples.
    """
    tokens = []
    position = 0
    
    # Define token patterns
    patterns = [
        ('WHITESPACE', r'[ \t]+'),
        ('NEWLINE', r'\n'),
        ('STRING', r'"[^"]*"'),
        ('NUMBER', r'\d+(\.\d*)?'),
        ('IDENTIFIER', r'[a-zA-Z_]\w*'),
        ('OPERATOR', r'[\+\-\*/=<>!]=?|[&|]{2}'),
        ('DELIMITER', r'[\(\)\{\}\[\],;:]'),
        ('COMMENT', r'#.*'),
    ]
    
    # Combine patterns into single regex
    token_regex = '|'.join(f'(?P<{name}>{pattern})' for name, pattern in patterns)
    token_matcher = re.compile(token_regex)
    
    # Process source code
    while position < len(source):
        match = token_matcher.match(source, position)
        
        if match is None:
            # Handle invalid characters
            raise SyntaxError(f"Invalid character at position {position}")
            
        position = match.end()
        
        # Get the name of the matched token
        token_type = match.lastgroup
        token_value = match.group()
        
        # Skip whitespace and comments
        if token_type in ('WHITESPACE', 'COMMENT'):
            continue
            
        tokens.append((token_type, token_value))
    
    return tokens
