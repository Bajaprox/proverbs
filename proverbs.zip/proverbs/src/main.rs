
use std::collections::HashMap;
use std::io::{self, Write};

#[derive(Debug)]
enum Token {
    Word(String),
    Number(f64),
    Plus,
    Minus,
    Multiply,
    Divide,
    Assign,
    EndStatement,
}

struct Interpreter {
    variables: HashMap<String, f64>,
}

impl Interpreter {
    fn new() -> Self {
        Interpreter {
            variables: HashMap::new(),
        }
    }

    fn tokenize(&self, input: &str) -> Vec<Token> {
        let mut tokens = Vec::new();
        let mut chars = input.chars().peekable();

        while let Some(&c) = chars.peek() {
            match c {
                '0'..='9' => {
                    let mut number = String::new();
                    while let Some(&c) = chars.peek() {
                        if c.is_digit(10) || c == '.' {
                            number.push(c);
                            chars.next();
                        } else {
                            break;
                        }
                    }
                    tokens.push(Token::Number(number.parse().unwrap()));
                }
                '+' => {
                    tokens.push(Token::Plus);
                    chars.next();
                }
                '-' => {
                    tokens.push(Token::Minus);
                    chars.next();
                }
                '*' => {
                    tokens.push(Token::Multiply);
                    chars.next();
                }
                '/' => {
                    tokens.push(Token::Divide);
                    chars.next();
                }
                '=' => {
                    tokens.push(Token::Assign);
                    chars.next();
                }
                ';' => {
                    tokens.push(Token::EndStatement);
                    chars.next();
                }
                c if c.is_alphabetic() => {
                    let mut word = String::new();
                    while let Some(&c) = chars.peek() {
                        if c.is_alphabetic() {
                            word.push(c);
                            chars.next();
                        } else {
                            break;
                        }
                    }
                    tokens.push(Token::Word(word));
                }
                ' ' | '\t' | '\n' => {
                    chars.next();
                }
                _ => panic!("Unexpected character: {}", c),
            }
        }
        tokens
    }

    fn evaluate(&mut self, tokens: Vec<Token>) -> Option<f64> {
        let mut iter = tokens.iter();
        let mut result = None;

        while let Some(token) = iter.next() {
            match token {
                Token::Word(var) => {
                    if let Some(Token::Assign) = iter.next() {
                        if let Some(Token::Number(val)) = iter.next() {
                            self.variables.insert(var.clone(), *val);
                            result = Some(*val);
                        }
                    } else {
                        result = self.variables.get(var).copied();
                    }
                }
                Token::Number(n) => {
                    result = Some(*n);
                }
                _ => {}
            }
        }
        result
    }
}

fn main() {
    let mut interpreter = Interpreter::new();
    
    loop {
        print!("> ");
        io::stdout().flush().unwrap();
        
        let mut input = String::new();
        io::stdin().read_line(&mut input).unwrap();
        
        let input = input.trim();
        if input == "exit" {
            break;
        }

        let tokens = interpreter.tokenize(input);
        if let Some(result) = interpreter.evaluate(tokens) {
            println!("=> {}", result);
        }
    }
}
