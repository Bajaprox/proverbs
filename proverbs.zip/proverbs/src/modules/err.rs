
use std::fmt;
use std::error::Error;

#[derive(Debug)]
pub enum ProverbError {
    ParseError(String),
    RuntimeError(String),
    TypeError(String),
    SyntaxError(String),
    UndefinedVariable(String),
    InvalidOperation(String),
}

impl fmt::Display for ProverbError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            ProverbError::ParseError(msg) => write!(f, "Parse Error: {}", msg),
            ProverbError::RuntimeError(msg) => write!(f, "Runtime Error: {}", msg),
            ProverbError::TypeError(msg) => write!(f, "Type Error: {}", msg),
            ProverbError::SyntaxError(msg) => write!(f, "Syntax Error: {}", msg),
            ProverbError::UndefinedVariable(msg) => write!(f, "Undefined Variable: {}", msg),
            ProverbError::InvalidOperation(msg) => write!(f, "Invalid Operation: {}", msg),
        }
    }
}

impl Error for ProverbError {}

pub type Result<T> = std::result::Result<T, ProverbError>;

pub fn create_parse_error(msg: &str) -> ProverbError {
    ProverbError::ParseError(msg.to_string())
}

pub fn create_runtime_error(msg: &str) -> ProverbError {
    ProverbError::RuntimeError(msg.to_string())
}

pub fn create_type_error(msg: &str) -> ProverbError {
    ProverbError::TypeError(msg.to_string())
}

pub fn create_syntax_error(msg: &str) -> ProverbError {
    ProverbError::SyntaxError(msg.to_string())
}

pub fn create_undefined_var_error(msg: &str) -> ProverbError {
    ProverbError::UndefinedVariable(msg.to_string())
}

pub fn create_invalid_op_error(msg: &str) -> ProverbError {
    ProverbError::InvalidOperation(msg.to_string())
}
