use std::str::Chars;

#[derive(Debug, PartialEq)]
pub enum Token {
    Number(f64),
    String(String),
    Identifier(String),
    Let,
    If,
    Else,
    While,
    Function,
    Return,
    Plus,
    Minus,
    Multiply,
    Divide,
    Equals,
    LeftParen,
    RightParen,
    LeftBrace,
    RightBrace,
    Semicolon,
    EOF,
}

pub struct Parser {
    input: String,
    chars: Chars<'static>,
    current_char: Option<char>,
}

impl Parser {
    pub fn new(input: String) -> Self {
        let chars = unsafe { std::mem::transmute(input.chars()) };
        let mut parser = Parser {
            input,
            chars,
            current_char: None,
        };
        parser.advance();
        parser
    }

    fn advance(&mut self) {
        self.current_char = self.chars.next();
    }

    fn skip_whitespace(&mut self) {
        while let Some(c) = self.current_char {
            if !c.is_whitespace() {
                break;
            }
            self.advance();
        }
    }

    fn parse_number(&mut self) -> Token {
        let mut number_str = String::new();
        
        while let Some(c) = self.current_char {
            if c.is_digit(10) || c == '.' {
                number_str.push(c);
                self.advance();
            } else {
                break;
            }
        }

        Token::Number(number_str.parse().unwrap())
    }

    fn parse_identifier(&mut self) -> Token {
        let mut identifier = String::new();
        
        while let Some(c) = self.current_char {
            if c.is_alphanumeric() || c == '_' {
                identifier.push(c);
                self.advance();
            } else {
                break;
            }
        }

        match identifier.as_str() {
            "let" => Token::Let,
            "if" => Token::If,
            "else" => Token::Else,
            "while" => Token::While,
            "function" => Token::Function,
            "return" => Token::Return,
            _ => Token::Identifier(identifier),
        }
    }

    fn parse_string(&mut self) -> Token {
        self.advance(); // Skip opening quote
        let mut string = String::new();
        
        while let Some(c) = self.current_char {
            if c == '"' {
                self.advance(); // Skip closing quote
                break;
            }
            string.push(c);
            self.advance();
        }

        Token::String(string)
    }

    pub fn next_token(&mut self) -> Token {
        self.skip_whitespace();

        match self.current_char {
            None => Token::EOF,
            Some(c) => {
                match c {
                    '0'..='9' => self.parse_number(),
                    'a'..='z' | 'A'..='Z' | '_' => self.parse_identifier(),
                    '"' => self.parse_string(),
                    '+' => { self.advance(); Token::Plus },
                    '-' => { self.advance(); Token::Minus },
                    '*' => { self.advance(); Token::Multiply },
                    '/' => { self.advance(); Token::Divide },
                    '=' => { self.advance(); Token::Equals },
                    '(' => { self.advance(); Token::LeftParen },
                    ')' => { self.advance(); Token::RightParen },
                    '{' => { self.advance(); Token::LeftBrace },
                    '}' => { self.advance(); Token::RightBrace },
                    ';' => { self.advance(); Token::Semicolon },
                    _ => panic!("Unexpected character: {}", c),
                }
            }
        }
    }

    pub fn parse(&mut self) -> Vec<Token> {
        let mut tokens = Vec::new();
        loop {
            let token = self.next_token();
            if token == Token::EOF {
                break;
            }
            tokens.push(token);
        }
        tokens
    }
}
