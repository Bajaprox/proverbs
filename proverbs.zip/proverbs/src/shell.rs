
use std::io::{self, Write};
use std::process;

pub struct Shell {
    prompt: String,
}

impl Shell {
    pub fn new() -> Shell {
        Shell {
            prompt: "proverbs> ".to_string(),
        }
    }

    pub fn run(&mut self) {
        loop {
            print!("{}", self.prompt);
            io::stdout().flush().unwrap();

            let mut input = String::new();
            match io::stdin().read_line(&mut input) {
                Ok(_) => {
                    let input = input.trim();
                    if input == "exit" || input == "quit" {
                        process::exit(0);
                    }
                    if input.is_empty() {
                        continue;
                    }
                    self.execute(input);
                }
                Err(error) => {
                    println!("Error reading input: {}", error);
                }
            }
        }
    }

    fn execute(&self, input: &str) {
        // TODO: Add interpreter/parser integration here
        println!("Executing: {}", input);
    }
}
