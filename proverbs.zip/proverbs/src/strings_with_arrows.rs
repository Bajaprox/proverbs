
pub fn string_with_arrows(text: &str, pos_start: usize, pos_end: usize) -> String {
    let mut result = String::new();
    let mut idx_start = text[..pos_start].rfind('\n').map_or(0, |i| i + 1);
    let idx_end = text[idx_start..].find('\n').map_or(text.len(), |i| idx_start + i);

    let line_count = text[idx_start..pos_start].chars().filter(|&c| c == '\n').count() + 1;
    let line = &text[idx_start..idx_end];
    
    result.push_str(&format!("{}\n", line));
    
    let mut col_start = pos_start - idx_start;
    let col_end = pos_end - idx_start;
    
    // Calculate padding
    let padding = " ".repeat(col_start);
    let arrows = "^".repeat(if col_end - col_start > 0 { col_end - col_start } else { 1 });
    
    result.push_str(&format!("{}{}", padding, arrows));
    
    result
}
